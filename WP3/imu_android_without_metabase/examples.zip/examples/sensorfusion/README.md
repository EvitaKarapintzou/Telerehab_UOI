# Sensor Fusion
The sensor fusion app demonstrates how to stream quaternion values from MetaMotion boards and use that information to update the 
orientation of a cube in 3D space.  OpenGL code is taken from [edumobile.org](http://www.edumobile.org/android/touch-rotate-example-in-android/).  
