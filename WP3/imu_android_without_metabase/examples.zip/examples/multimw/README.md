# Multi MetaWear
The multimw module demonstrates how to connect to multiple MetaWears using the MetaWear 2.X API.
