# Free Fall Detector
The free fall app demonstrates how to use the on-board data processing to determine if the board is in free fall using accelerometer data 
and records the events to the flash memory.  This is the companion app to the [free fall tutorial](https://mbientlab.com/docs/apis/java/freefall-app/) 
and is what your code should resemble after completing the videos.  
